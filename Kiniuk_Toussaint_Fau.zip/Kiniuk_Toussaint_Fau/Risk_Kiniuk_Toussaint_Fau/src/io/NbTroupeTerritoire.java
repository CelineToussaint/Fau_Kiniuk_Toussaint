package io;

import java.awt.Font;

import javax.swing.JLabel;

import risk.Partie;
import risk.Territoire;

/**
 * classe NbTroupeTerritoire : permet d'afficher le nombre de troupes sur un territoire
 * @author fau_kinuk_toussaint
 *
 */
public class NbTroupeTerritoire extends JLabel{
	
	/**
	 * attribut Partie partie : permet de mod�liser la partie en cours
	 */
	private Partie partie;
	
	/**
	 * attribut Territoire territoire : correspond au territoire concern�
	 */
	private Territoire territoire;
	
	/**
	 * attribut int x : correspond � la coordonn�e x
	 */
	private int x;
	
	/**
	 * attribut int y : correspond � la coordonn�e y
	 */
	private int y;
	
	/**
	 * m�thode NbTroupeTerritoire : constructeur
	 * @param partie : la partie en cours
	 * @param territoire : le territoire consid�r�
	 * @param x : la coordonn�e x
	 * @param y : la coordonn�e y
	 */
	public NbTroupeTerritoire(Partie partie,Territoire territoire,int x,int y) {
		this.partie = partie;
		this.territoire = territoire;
		this.setBounds(x,y,20,20);
		this.setText(Integer.toString(this.territoire.afficherNbPions()));
		this.setFont(new Font("Arial", Font.BOLD, 16));
	}

}
