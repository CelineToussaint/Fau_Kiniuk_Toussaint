package io;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import risk.Partie;
import risk.Territoire;

/**
 * classe BoutonTerritoire : classe servant � cr�er les boutons pour pouvoir jouer sur l'interface
 * @author fau_kinuk_toussaint
 *
 */
public class BoutonTerritoire extends JButton implements ActionListener{
	
	/**
	 * attribut Partie partie : repr�sente une partie du Risk
	 */
	private Partie partie;
	
	/**
	 * attribut Territoire territoire : permet de mod�liser un territoire de la carte
	 */
	private Territoire territoire;
	
	/**
	 * attribut int x : position en abscisse du bouton 
	private int x;
	
	/**
	 * attribut int y : position en ordonn�es du bouton
	 */
	private int y;
	
	/**
	 * constructeur de la classe BoutonTerritoire
	 * @param partie : la partie en cours
	 * @param territoire : le territoire concern�
	 * @param x : la coordonn�e x du bouton
	 * @param y : la coordonn�e y du bouton
	 */
	public BoutonTerritoire(Partie partie,Territoire territoire,int x,int y) {
		this.partie = partie;
		this.territoire = territoire;
		this.setBounds(x,y,120,20);
		String s = territoire.getNom();
		this.setText(s);
		this.setFont(new Font("Arial", Font.PLAIN, 12));
		this.addActionListener(this);
	}
	
	/**
	 * m�thode actionPerformed : permet de prendre en compte l'action des boutons
	 * @param e : action
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
			this.partie.setTerritoireSelectionee(this.territoire);
	}

}
