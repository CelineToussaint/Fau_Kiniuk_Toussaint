package io;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 * classe FondDeCarte : permet de r�aliser le fond de carte pour jouer au Risk
 * @author fau_kinuk_toussaint
 *
 */
public class FondDeCarte extends JPanel {
	
	/**
	 * attribut Image fond : image qui va servir de fond au jeu du Risk
	 */
	private Image fond;
	
	/**
	 * m�thode FondDeCarte : permet d'importer l'image qui sert de fond
	 * @param image : l'image qui va servir de fond
	 */
	public FondDeCarte(Image image) {
		this.fond = image;
		this.setLayout(null);
	}
	
	
	/**
	 * m�thode paintComponent : permet d'actualiser le fond de carte � chaque tour
	 * @param g : les graphiques
	 */
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		//System.out.println("Je suis exécutée !");
		g2d.drawImage(this.fond,0,0,(int)this.fond.getWidth(null)*1800/this.fond.getWidth(null),(int)this.fond.getHeight(null)*1000/this.fond.getHeight(null),null);
	}

}
