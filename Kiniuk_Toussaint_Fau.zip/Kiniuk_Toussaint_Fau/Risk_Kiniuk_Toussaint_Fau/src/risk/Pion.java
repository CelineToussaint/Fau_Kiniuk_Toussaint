package risk;

/**
 * 
 * @author fau_kinuk_toussaint
 * classe Pion qui modélise un pion. Ils sont utilisés pour occuper un territoire, attaquer et défendre.
 *
 */
public class Pion {
	
	//déclaration des attributs
	/**
	 * attribut Joueur possesseur : joueur possesseur du pion en question.
	 */
	private Joueur possesseur;
	
	/**
	 * attribut Territoire lieu : territoire sur lequel se trouve le pion en question.
	 */
	private Territoire lieu;
	
	/**
	 * attribut boolean deplacable : permet d'indiquer si le pion s'est déjà déplacé, auquel cas le booléen renvoie false 
	 * et le pion ne peut être utilisé à nouveau.
	 */
	private boolean deplacable;
	
	//méthodes
	
	/**
	 * méthode deplacement : modélise le déplacement d'un pion d'un territoire vers un autre
	 * @param territoireArrivee : territoire d'arrivée du pion, adjacent au lieu où se trouve le pion
	 */
	public void deplacement(Territoire territoireArrivee) {
		if (deplacable) {
			//si le pion est déplaçable, on doit l'enlever de son ancien territoire puis l'ajouter à son nouveau territoire
			this.lieu.getListePion().remove(this);
			this.lieu = territoireArrivee;
			this.lieu.getListePion().add(this);
			this.deplacable = false;
		}
		else {
			//sinon, on renvoie une erreur
			System.out.println("ERREUR : pion non déplacable !!!");
		}
	}
	
	/**
	 * constructeur de la classe Pion
	 * méthode Pion : permet de créer un pion sur un territoire
	 * @param territoire : territoire où est créé le pion
	 */
	public Pion (Territoire territoire) {
		this.lieu = territoire;
		this.possesseur = territoire.getPossesseur();
		this.deplacable = true;
	}

	
	//getter setter
	
	/**
	 * getter
	 * méthode isDeplacable : permet d'accéder au booléen qui indique si le pion est déplaçable ou pas
	 * @return deplacable : ledit booléen
	 */
	public boolean isDeplacable() {
		return deplacable;
	}

	/**
	 * setter
	 * méthode setDeplacable : permet d'indiquer si le pion est déplaçable ou pas via un booléen
	 * @param deplacable : ledit booléen
	 */
	public void setDeplacable(boolean deplacable) {
		this.deplacable = deplacable;
	}
	
	
}
