package risk;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * classe Partie : modélise une partie de Risk
 * @author fau_kinuk_toussaint
 */
public class Partie {
	
	//déclaration des variables
	/**
	 * attribut boolean enCours : indique que la partie n'est pas finie
	 */
	private boolean enCours;
	
	/**
	 * attribut int nbJoueur : correspond au nombre de joueurs d'une partie
	 */
	private int nbJoueurs;
	
	/**
	 * attribut List<Joueur> listeJoueurs : liste des joueur dans la partie
	 */
	private List<Joueur> listeJoueurs;
	
	/**
	 * attribut List<Continent> listeContinents : liste des continent de la carte
	 */
	private List<Continent> listeContinents;
	
	/**
	 * attribut Joueur joueurActif : indique le nom du joueur actif
	 */
	private Joueur joueurActif;
	
	/**
	 * attribut int nbTours : correspond au numéro du tour courant
	 */
	private int nbTours;
	
	/**
	 * attribut String actionJoueur : correspond à l'action du joueur : soit "deplacer", soit "attaquer", soit "fin du tour"
	 */
	private String actionJoueur;
	
	/**
	 * attribut Territoire territoireSelectionee : correspond au territoire selectioné par le joueur.
	 */
	private Territoire territoireSelectionee;
	
	
	/**
	 * attribut int nbTourMax : correspond au nombre de tours d'une partie
	 */
	private int nbToursMax;
	
	//méthodes
	/**
	 * méthode addJoueur : permet d'ajouter un joueur à la liste de joueurs
	 * @param joueur : le joueur concerné
	 */
	public void addJoueur(Joueur joueur){
		this.listeJoueurs.add(joueur);
		this.nbJoueurs = this.nbJoueurs + 1;
	}

	/**
	 * méthode addContinent : permet d'ajouter un continent à la liste des continents
	 * @param continent : le continent qu'on veut ajouter
	 */
	public void addContinent(Continent continent){
		this.listeContinents.add(continent);
	}
	
	
	/**
	 * méthode removeJoueur : permet de retirer un joueur de la liste des joueurs, par exemple lorsqu'il a perdu
	 * @param joueur : le joueur concerné
	 */
	public void removeJoueur(Joueur joueur){
		this.listeJoueurs.remove(joueur);
		this.nbJoueurs = this.nbJoueurs -1;
	}

	/**
	 * constructeur de la classe Partie
	 * méthode Partie : permet de créer une nouvelle partie
	 */
	public Partie() {
		this.nbJoueurs = 0;
		this.listeJoueurs = new ArrayList<Joueur>();
		this.listeContinents = new ArrayList<Continent>();
		this.nbTours = 0;
		this.actionJoueur="";
	}
	
	/**
	 * constructeur de la classe Partie
	 * méthode Partie : permet de créer une nouvelle partie
	 * @param nbToursMax : le nombre de tours maximum qu'on se fixe
	 */
	public Partie(int nbToursMax) {
		this.nbJoueurs = 0;
		this.listeJoueurs = new ArrayList<Joueur>();
		this.listeContinents = new ArrayList<Continent>();
		this.nbTours = 0;
		this.nbToursMax = nbToursMax;
		this.actionJoueur="fin du tour";
	}
	
	/**
	 * méthode lancerPartie : permet de lancer la partie, on distribue aléatoirement les territoires aux joueurs et on place un pion sur
	 * chaque territoire.  
	 */
	public void lancerPartie() {
		
		//on définit le joueur actif comme étant le premier joueur de la liste de joueurs
		this.joueurActif = listeJoueurs.get(0);
		//on initialise le nombre de tours à 0
		this.nbTours =0;
		//on initialise la liste de territoires
		List<Territoire> listeTerritoire = new ArrayList<Territoire>();
		for( int i=0;i<this.listeContinents.size(); i++) {
			for (int c = 0; c<this.listeContinents.get(i).getListeTerritoires().size(); c++){
				listeTerritoire.add(this.listeContinents.get(i).getListeTerritoires().get(c));
			}
		}
		int numJoueur =0;
		int iteration = listeTerritoire.size();
		for(int i = 0; i< iteration; i++) {
			int territoireAlea = (int)(Math.random()*listeTerritoire.size());
			this.listeJoueurs.get(numJoueur).addTerritoire(listeTerritoire.get(territoireAlea));

			listeTerritoire.get(territoireAlea).setPossesseur(this.listeJoueurs.get(numJoueur));
			Pion pion = new Pion(listeTerritoire.get(territoireAlea));
			listeTerritoire.get(territoireAlea).addPion(pion);
			if (numJoueur<this.listeJoueurs.size()-1) {
				numJoueur = numJoueur + 1;
			}
			else {
				numJoueur=0;
			}
			listeTerritoire.remove(listeTerritoire.get(territoireAlea));
		}
	}
		
		
		

	/**
	 * méthode verifierJoueurElimine : vérifie si des joueurs n'ont plus de territoires et sont donc éliminés.
	 */
	public void verifierJoueurElimine() {
		for(int i=0; i<this.listeJoueurs.size(); i++) {
			if (this.listeJoueurs.get(i).getListeTerritoires().size() == 0){
				this.listeJoueurs.remove(this.listeJoueurs.get(i));
				this.nbJoueurs = this.nbJoueurs - 1;
				
			}
		}
	}
	
	/**
	 * méthode etatPlateau : affiche l'état du plateau de jeu. On va l'utiliser lors de prises de décisions.
	 */
	public void etatPlateau() {
		//on affiche les territoires avec leur possesseur et le
		//nombre de pion dessus
		
		for (int i=0 ; i<nbJoueurs;i++) {
			for (int j = 0; j<listeJoueurs.get(i).getListeTerritoires().size();j++) {
				System.out.println("Territoire : " + listeJoueurs.get(i).getListeTerritoires().get(j).getNom()+" Joueur : "+listeJoueurs.get(i).getNomJoueur() +" Nombre de pions : "+ listeJoueurs.get(i).getListeTerritoires().get(j).getListePion().size());
			}
			
		}
		
	}
	
	
	
	/**
	 * Méthode waitSelecTerritoire : ne se finit que si l'attribut TerritoireSelectionne est chang� par un joueur.
	 */
	public void waitSelecTerritoire() {
		this.setTerritoireSelectionee(null);
		while (this.getTerritoireSelectionee() == null) {
			System.out.print("");
		}
	}
	
	/**
	 * Méthode waitActionJoueur : ne se finit que si l'attribut actionJoueur est chang� par un joueur.
	 */
	public void waitActionJoueur() {
		this.setActionJoueur("");
		while (this.getActionJoueur() == "") {
			System.out.print("");
		}
	}
	
	/**
	 * m�thode donneTerritoire : permet de retrouver un objet Territoire avec son nom
	 * @param nomTerritoire : nom du territoire désiré
	 * @return territoire : le territoire désiré
	 */
	public Territoire donneTerritoire(String nomTerritoire) {
		for(Continent continent : this.listeContinents) {
			for(Territoire territoire : continent.getListeTerritoires()) {
				if(territoire.getNom().compareTo(nomTerritoire)==0) {
					return(territoire);
				}
			}
		}
		return(null);
	}
	
	/**
	 * m�thode territoireExiste : permet de savoir � partir du nom d'un territoire s'il existe
	 * @param nomTerritoire : nom du territoire recherché
	 * @return true si le territoire existe, false sinon.
	 */
	public boolean territoireExiste(String nomTerritoire) {
		for(Continent continent : this.listeContinents) {
			for(Territoire territoire : continent.getListeTerritoires()) {
				if(territoire.getNom().compareTo(nomTerritoire)==0) {
					return(true);
				}
			}
		}
		return(false);
	}
	

	
	
	//getter et setter
	
	
	/**
	 * getter 
	 * m�thode getTerritoireSelectionee
	 * @return territoireSelectionee
	 */
	public Territoire getTerritoireSelectionee() {
		return territoireSelectionee;
	}
	
	/**
	 * setter
	 * m�thode setTerritoireSelectionee
	 * @param territoireSelectionee : le territoire s�lectionn�
	 */
	public void setTerritoireSelectionee(Territoire territoireSelectionee) {
		this.territoireSelectionee = territoireSelectionee;
	}
	
	/**
	 * setter
	 * méthode setListeJoueurs : permet de définir la liste des joueurs de la partie
	 * @param listeJoueurs : ladite liste de joueurs
	 */
	public void setListeJoueurs(List<Joueur> listeJoueurs) {
		this.listeJoueurs = listeJoueurs;
	}

	/**
	 * getter
	 * méthode getListeJoueurs : permet d'accéder à la liste des joueurs
	 * @return listeJoueurs : ladite liste de joueurs
	 */
	public List<Joueur> getListeJoueurs() {
		return listeJoueurs;
	}

	/**
	 * getter
	 * méthode getNbTours : permet d'accéder au nombre de tours écoulés
	 * @return nbTours : ledit nombre de tours
	 */
	public int getNbTours() {
		return nbTours;
	}

	/**
	 * getter
	 * méthode getNbToursMax : permet d'accéder au nombre de tours maximal
	 * @return nbToursMax : ledit nombre de tours
	 */
	public int getNbToursMax() {
		return nbToursMax;
	}

	/**
	 * setter
	 * méthode setNbTours : permet de fixer le nombre de tours
	 * @param nbTours : ledit nombre de tours
	 */
	public void setNbTours(int nbTours) {
		this.nbTours = nbTours;
	}

	/**
	 * getter
	 * méthode getJoueurActif : permet d'accéder au joueur actif
	 * @return joueurActif : ledit joueur actif
	 */
	public Joueur getJoueurActif() {
		return joueurActif;
	}

	/**
	 * setter
	 * méthode setJoueurActif : permet de définir le joueur actif
	 * @param joueurActif : ledit joueur actif
	 */
	public void setJoueurActif(Joueur joueurActif) {
		this.joueurActif = joueurActif;
	}
	


	/**
	 * getter
	 * méthode getListeContinents : permet d'accéder à la liste des continents
	 * @return listeContinents : ladit liste
	 */
	public List<Continent> getListeContinents() {
		return listeContinents;
	}

	/**
	 * setter
	 * méthode setListeContinents : permet de définir la liste de continents
	 * @param listeContinents : ladite liste
	 */
	public void setListeContinents(List<Continent> listeContinents) {
		this.listeContinents = listeContinents;
	}

	/**
	 * getter
	 * méthode getActionJoueur : permet d'accéder à l'action du joueur
	 * @return actionJoueur : ladite action du joueur
	 */
	public String getActionJoueur() {
		return actionJoueur;
	}

	/**
	 * setter
	 * méthode setActionJoueur : permet de définir l'action du joueur
	 * @param actionJoueur : ladite action 
	 */
	public void setActionJoueur(String actionJoueur) {
		this.actionJoueur = actionJoueur;
	}
	
	
	/**
	 * setter
	 * setNbToursMax : permet de configurer le nombre de tours limite à la partie
	 * @param nbToursMax : nombre désiré de tours max
	 */
	public void setNbToursMax(int nbToursMax) {
		this.nbToursMax=nbToursMax;
	}
	
	/**
	 * setter
	 * méthode setNbJoueurs : permet de configurer le nombre de joueurs
	 * @param nbJoueurs : nombre de joueurs
	 * 
	 */
	public void setNbJoueurs(int nbJoueurs) {
		this.nbJoueurs=nbJoueurs;
	}

	/**
	 * getter
	 * méthode getNbJoueurs : permet d'accéder au nombre de joueurs
	 * @return nbJoueurs : nombre de joueurs
	 */
	public int getNbJoueurs() {
		return nbJoueurs;
	}

	/**
	 * méthode isEnCours : permet de savoir si la partie est en cours à l'aide d'un booléen
	 * @return boolean enCours : true si elle est en cours, false sinon
	 */
	public boolean isEnCours() {
		return enCours;
	}

	/**
	 * setter
	 * méthode setEnCours : permet de configurer la valeur du booléen enCours qui permet de savoir si la partie est en cours
	 * @param enCours : true si la partie est en cours, false sinon
	 */
	public void setEnCours(boolean enCours) {
		this.enCours = enCours;
	}
	
}
