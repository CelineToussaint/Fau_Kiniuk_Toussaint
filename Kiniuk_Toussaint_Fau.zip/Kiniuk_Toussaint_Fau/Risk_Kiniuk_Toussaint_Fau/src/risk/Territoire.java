package risk;

import java.util.ArrayList;
import java.util.List;


import io.BoutonTerritoire;
import io.NbTroupeTerritoire;

/**
 * 
 * @author fau_kinuk_toussaint
 * classe Territoire : permet de modéliser un territoire parmi les territoires qui composent la carte
 *
 */
public class Territoire {
	
	//déclaration des attributs
	/**
	 * attribut String nom : nom du territoire
	 */
	private String nom;
	
	/**
	 * attribut Joueur possesseur : joueur possédant le territoire
	 */
	private Joueur possesseur;
	
	/**
	 * attribut List<Territoire> listeTerritoiresAdjacents : liste des territoires adjacents au territoire concerné
	 */
	private List<Territoire> listeTerritoiresAdjacents;
	
	/**
	 * attribut List<Pion> listePion : liste des pions présents sur le territoire
	 */
	private List<Pion> listePion;
	
	/**
	 * attribut NbTroupeTerritoire labelAssocie : label associé a ce territoire dans l'interface
	 */
	private NbTroupeTerritoire labelAssocie;
	
	/**
	 * attribut BoutonTerritoire boutonAssocie : bouton associé a ce territoire dans l'interface
	 */
	private BoutonTerritoire boutonAssocie;	

	
	
	//méthodes
	
	/**
	 * méthode afficherNbPions : affiche le nombre de pions d'un territoire 
	 * @return int le nombre de pions
	 */
	public int afficherNbPions() {
		return this.listePion.size();
	}


	/**
	 * constructeur de la classe Territoire 
	 * méthode Territoire : permet de créer un territoire
	 * @param nom : le nom du territoire
	 */
	public Territoire(String nom) {
		this.listeTerritoiresAdjacents = new ArrayList<Territoire>();
		this.listePion = new ArrayList<Pion>();
		this.nom = nom;
	}
	
	/**
	 * constructeur vide
	 * méthode Territoire : permet de créer un territoire
	 */
	public Territoire() {
		
	}

	/**
	 * méthode addTerritoireAdjacent : permet d'ajouter un territoire adjacent à la liste des territoires adjacents
	 * @param territoire : le territoire à ajouter
	 */
	public void addTerritoireAdjacent(Territoire territoire) {
		this.listeTerritoiresAdjacents.add(territoire);
		territoire.listeTerritoiresAdjacents.add(this);
	}
	
	/**
	 * méthode changePossesseur : méthode qui change le possesseur d'un territoire
	 * @param nouveauPossesseur : nouveau possesseur du joueur
	 */
	public void changePossesseur(Joueur nouveauPossesseur) {
		
		//on doit retirer le territoire à l'ancien possesseur
		this.possesseur.getListeTerritoires().remove(this);
		
		//on change le possesseur
		this.possesseur = nouveauPossesseur;
		
		//on ajoute le territoire au nouveau possesseur
		this.possesseur.getListeTerritoires().add(this);
	}
	
	/**
	 * méthode addPion : permet d'ajouter un pion à la liste de pions du territoire
	 * @param pion : pion qu'on veut ajouter
	 */
	public void addPion(Pion pion) {
		this.listePion.add(pion);
	}
	
	/**
	 * méthode update actualisant le bouton et le label du territoire 
	 */
	public void update() {
		this.labelAssocie.setText(Integer.toString(this.afficherNbPions()));
		this.labelAssocie.setForeground(this.possesseur.getCouleur());
	}
	
	
	/**
	 * méthode isTerritoireFrontalier : permet de savoir si le territoire en question est frontalier avec
	 * un territoire ennemi
	 * @return boolean : true si le territoire est en contact avec un territoire ennemi, false sinon
	 */
	public boolean isTerritoireFrontalier() {
		//on a accés é la liste des territoires adjacents, s'il y en a un dont le possesseur n'est pas
		//le possesseur du territoire courant, alors on renvoie true
		
		//on parcourt listeTerritoiresAdjacents
		for (int i = 0 ; i < listeTerritoiresAdjacents.size() ; i++) {
			if (listeTerritoiresAdjacents.get(i).getPossesseur() != possesseur) {
				return true;
			}
		}
		return false;
	}
	
	
	/**
	 * méthode TerritoiresEnnemisAdjacents : permet d'accéder aux territoires ennemis adjacents
	 * @return territoiresEnnAdj : la liste des territoires qui sont adjacents au territoire  considéré
	 */
	public List<Territoire> TerritoiresEnnemisAdjacents(){
		
		//on initialise une liste vide dans laquelle on va placer les territoires adjacents qui n'appartiennent
		//pas au possesseur du territoire considéré
		ArrayList<Territoire> territoiresEnnAdj = new ArrayList<Territoire>();
		
		//on parcourt la liste des territoires adjacents
		for (int i = 0 ; i < listeTerritoiresAdjacents.size() ; i++) {
			if (listeTerritoiresAdjacents.get(i).getPossesseur() != this.possesseur) {
				territoiresEnnAdj.add(listeTerritoiresAdjacents.get(i));
			}
		}
		return territoiresEnnAdj;
	}
	
	
	/**
	 * méthode listeTerritoireAdjacentsFrontaliers : permet de savoir si les territoires ennemis frontaliers au
	 * territoire ont eux-mémes des territoires frontaliers qui n'appartiennent pas au possesseur du territoire
	 * considéré
	 * @return listeTerr : la liste des territoires qui sont frontaliers aux territoires ennemis frontaliers
	 * et qui n'appartiennent pas au possesseur du territoire considéré
	 */
	public List<Territoire> listeTerritoireAdjacentsFrontaliers() {
		
		//on initialise une liste vide pour stocker les territoires ennemis 
		ArrayList<Territoire> listeTerr = new ArrayList<Territoire>();
		
		//on va parcourir la liste de territoires frontaliers ennemis et tester s'il y en a qui sont aussi aux 
		//ennemis
		//on renomme ladite liste
		List<Territoire> listeTerrAdj = TerritoiresEnnemisAdjacents();
		
		if (listeTerrAdj.size() == 0) {
			return listeTerr;//on retourne la liste vide
		}
		else {
			for (int i = 0 ; i<listeTerrAdj.size();i++) {
				if (listeTerrAdj.get(i).getPossesseur() != this.possesseur) {
					listeTerr.add(listeTerrAdj.get(i));
				}
			}
			return listeTerr;
		}
	}
	
	
	/**
	 * méthode pionsDisponibles : méthode qui indique le nombre de pions disponibles pour l'attaque sur le territoire
	 * @return int compteur : le nombre de pions qui peuvent servir à l'attaque
	 */
	public int pionsDisponibles() {
		int nbPions = this.listePion.size();
		//on parcourt la liste des pions du territoire et on vérifie s'il y en a qui sont déplaçables
		//initialisation d'une variable compteur
		int compteur = 0;
		for (int i = 0; i<nbPions;i++) {
			if (this.listePion.get(i).isDeplacable()) {
				compteur += 1;
			}
		}
		compteur = compteur -1;
		return compteur;
	}

	
	//getter et setter
	
	/**
	 * getter
	 * méthode getListeTerritoiresAdjacents : permet d'accéder à la liste des territoires adjacents
	 * @return listeTerritoiresAdjacents : ladite liste
	 */
	public List<Territoire> getListeTerritoiresAdjacents() {
		return listeTerritoiresAdjacents;
	}
	

	/**
	 * getter
	 * méthode getNom : permet d'accéder au nom du territoire
	 * @return String nom : ledit nom
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * getter
	 * méthode getListePion : permet d'accéder à la liste des pions du territoire
	 * @return listePion : ladite liste de pions
	 */
	public List<Pion> getListePion() {
		return listePion;
	}
	/**
	 * getter
	 * méthode getPossesseur : permet d'accéder au possesseur d'un territoire
	 * @return possesseur : le possesseur du territoire
	 */
	public Joueur getPossesseur() {
		return possesseur;
	}

	/**
	 * setter 
	 * méthode setPossesseur : permet de définir le possesseur du territoire
	 * @param possesseur : le nouveau possesseur du territoire
	 */
	public void setPossesseur(Joueur possesseur) {
		this.possesseur = possesseur;
	}
	
	/**
	 * setter 
	 * méthode setListePion : permet de définir la liste des pions d'un territoire
	 * @param listePion : ladite liste
	 */
	public void setListePion(List<Pion> listePion) {
		this.listePion= listePion;
	}

	/**
	 * getter
	 * m�thode getLabelAssocie
	 * @return labelAssocie
	 */
	public NbTroupeTerritoire getLabelAssocie() {
		return labelAssocie;
	}
	
	/**
	 * setter
	 * m�thode setLabelAssocie
	 * @param labelAssocie : le label associ� au bouton
	 */
	public void setLabelAssocie(NbTroupeTerritoire labelAssocie) {
		this.labelAssocie = labelAssocie;
	}
	
	/**
	 * getter
	 * m�thode getBoutonAssocie
	 * @return boutonAssocie
	 */
	public BoutonTerritoire getBoutonAssocie() {
		return boutonAssocie;
	}
	
	/**
	 * setter
	 * m�thode setBoutonAssocie
	 * @param boutonAssocie : le bouton associ� au territoire
	 */
	public void setBoutonAssocie(BoutonTerritoire boutonAssocie) {
		this.boutonAssocie = boutonAssocie;
	}
	
}
