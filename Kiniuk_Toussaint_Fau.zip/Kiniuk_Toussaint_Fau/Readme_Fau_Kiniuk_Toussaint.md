﻿

README
======

Titre de l'application : **Risk**
Auteurs de l'application : FAU Benjamin, KINIUK Allan, TOUSSAINT Céline


Le Risk
-------
Le Risk est un jeu de société qui nécessite deux à six joueurs. Ces derniers disposent d'une carte du monde simplifiée, et découpée en continents, eux-mêmes divisés en territoires.

![enter image description here](https://lh3.googleusercontent.com/-XWOzYCppOgY/XNPkPv7q-1I/AAAAAAAAAD8/ZzsMXyxztoMK2jyPlu8zpg-XkVwFkDpiACLcBGAs/s0/Map+Risk.PNG "Map Risk.PNG")

Ainsi, le continent Europe est divisé en Europe du Nord, Angleterre, France/Espagne, Islande, Russie, Allemagne, Grèce/Italie.

![enter image description here](https://lh3.googleusercontent.com/-PIapA58wQFY/XNPj90DJAzI/AAAAAAAAADw/j16-3aymhvUGD01BsD3sZRr5Ay5yoUmiwCLcBGAs/s0/Europe.png "Europe")

Le but du jeu est d'être le dernier joueur survivant.
En début de partie, chacun des joueurs se verra attribuer un certain nombre de territoires, et des troupes qui vont être représentés par des pions. 
Pour prendre des territoires ennemis, le joueur pourra déplacer ses troupes et attaquer.
Ici, notre objectif était de réaliser une modélisation informatique de ce célèbre jeu de plateau. Nous avons ainsi codé en Java, et implémenté une interface graphique pour jouer plus facilement.
De plus, il est possible de jouer contre une intelligence artificielle (niveau 0, 1 ou 2).


Comment installer l'application ?
---------------------------------
Tout d'abord, l'on a accès à un dossier compressé qui contient :

 - un fichier .exe qui va lancer l'application
 
 - un dossier Map qui contient 4 fichiers textes et une carte. La carte représente le plateau de jeu, et les 4 fichiers textes des précisions sur la carte, pour pouvoir jouer.
 Le fichier territoire permet de spécifier les Territoires du jeu, continent les Continents, frontière les frontières entre les différents territoires (cela permet notamment de savoir si l'on peut attaquer ou déplacer ses pions) et un fichier positionbouton qui a permis de placer les boutons sur la carte.


Pour installer l'application, il faut double cliquer sur l'exécutable fourni, et l'application ainsi que l'interface vont se lancer automatiquement.
L'on peut ensuite commencer une partie.

Comment utiliser l'application ?
--------------------------------

 - **Lancer la partie**

Pour jouer au Risk, l'on doit d'abord lancer l'application (double cliquer sur l'exécutable).
Une fenêtre d'options apparaît, permettant d'indiquer le nombre de joueurs, leur nom et s'il s'agit d'une intelligence artificielle ou pas.
L'on peut aussi choisir le nombre de tours maximum de la partie.
Dans cette fenêtre il faut aussi indiquer la direction du dossier Map.
Une fois que les options sont à la guise du joueur, il peut cliquer sur le bouton : **lancer la partie**.

![enter image description here](https://lh3.googleusercontent.com/-oWtCeGqQOF8/XNQ88QVkxXI/AAAAAAAAAEw/WkzOKT-XV1g_eyB5KDNc-1fbEeKFs8kggCLcBGAs/s0/Settings+Risk.png "Settings Risk.png")

 - **Jouer**
 
Les joueurs vont donc pouvoir jouer tour à tour. Le joueur courant est affiché en haut de la carte du Risk.
Ce dernier doit d'abord placer les renforts qu'il a en début de tour. Il va cliquer sur les boutons des différents territoires lui appartenant pour y ajouter des pions. 

Exemple : comme le joueur actif est le rouge, on peut par exemple cliquer sur l'Oural qui lui appartient (nombre de renfort en rouge).

![enter image description here](https://lh3.googleusercontent.com/-Xt5MqxbD_Ac/XNPnlVsmfiI/AAAAAAAAAEQ/SSLrnVnrXwsoRj2UwapoviFsX6rRrwooACLcBGAs/s0/Renfort.png "Renfort.png")

Ces derniers s'ajoutent un à un.
De plus, une couleur est attribuée à chaque joueur, permettant de visualiser rapidement où sont les territoires lui appartenant, et ceux de ses ennemis.
Ici, on a par exemple le bleu et le rouge.
Ensuite, le joueur a le choix entre attaquer, déplacer ses troupes et finir son tour (ces trois options sont matérialisées par trois boutons en bas à gauche de la carte).

![enter image description here](https://lh3.googleusercontent.com/-rO-1uQy2UGs/XNPn9aRbskI/AAAAAAAAAEc/5gKkd_AqxVcRknqe5f8-AflweFg177xAQCLcBGAs/s0/boutons.png "boutons.png")

Pour **attaquer**, il faut cliquer sur le bouton attaquer, puis choisir le nombre de pions qui vont être lancés (de un à trois), ensuite sur le bouton du territoire attaquant puis on appuie sur le bouton du territoire attaqué. 
Il va y avoir un lancé de dés : celui de l'attaquant ou du défenseur qui aura parmi leurs dés les plus forts le plus haut score gagnera la manche, et soit le défenseur perdra son (ses) pion(s), soit c'est l'attaquant.

L'attaquant peut attaquer autant de fois qu'il veut, du moment qu'il a assez de pions disponibles. En effet, lors du tour d'un joueur, si le pion a déjà été utilisé pour une attaque ou pour un déplacement au préalable, il ne peut plus être utilisé jusqu'à la fin de son tour.

Si l'on se fait attaquer par un autre joueur, le territoire attaqué se **défend** : s'il y a un seul pion sur le territoire, alors l'on ne défend qu'avec un seul pion (donc on va lancer un seul dé) et si l'on a plus de deux pions sur le territoire, on défend avec deux pions (et on lancera deux dés). L'on n'a donc pas besoin ici de choisir avec combien de pions on défend le territoire attaqué.

Pour **déplacer** des troupes, il suffit de cliquer sur le bouton déplacer, choisir le nombre de pions  qu'on veut déplacer, le territoire d'où partent les troupes, puis sur le territoire où ils arrivent. 




 - **Fin de la partie**

La partie est finie dans deux cas :

 - Si un joueur s'est emparé de toute la carte
 
Dans ce cas, il est le gagnant de la partie de Risk.

 - Si le nombre de tours maximum est atteint

Alors l'on va déclarer vainqueur le joueur ayant le plus de territoires.

Bonne partie de Risk !
==============