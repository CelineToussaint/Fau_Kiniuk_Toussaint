package io;

import java.awt.Image;

import javax.swing.JFrame;

/**
 * classe Fenetre : permet de mod�liser une fen�tre dans le Risk
 * @author fau_kinuk_toussaint
 *
 */
public class Fenetre extends JFrame {

	/**
	 * constructeur de la classe Fenetre 
	 */
	public Fenetre() {
		this.init();
	}
	
	/**
	 * m�thode init : permet d'initialiser la fen�tre
	 */
	private void init(){
		this.setTitle("Risk");
		this.setSize(1800,1040);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}

}
