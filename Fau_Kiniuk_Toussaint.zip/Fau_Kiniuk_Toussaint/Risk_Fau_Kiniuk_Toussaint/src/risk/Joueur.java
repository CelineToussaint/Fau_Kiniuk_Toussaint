package risk;

import java.awt.Color;
import java.util.*;

/**
 * classe Joueur qui représente un joueur de Risk.
 * @author fau_kinuk_toussaint
 */
public class Joueur {
	
	//déclaration des attributs
	/**
	 * attribut Partie partie : permet d'avoir accés à la partie jouée
	 */
	private Partie partie;
	
	
	
	/**
	 * attribut String nomJoueur : représente le nom du joueur
	 */
	private String nomJoueur;
	
	
	/**
	 * attribut Color couleur : couleur representant le joueur
	 */
	private Color couleur;
	
	
	/**
	 * attribut boolean iA : permet de spécifier s'il y a une intelligence artificielle (booléen = true) ou non (booléen = false)
	 */
	private boolean iA;
	
	/**
	 * attribut String niveau : indique le niveau de l'intelligence artificielle. niveau0 (l'IA joue de manière presque aléatoire,
	 * plus facile pour le joueur) ou niveau1 (l'IA est d'intelligence basique)...
	 * Si le Joueur n'est pas une iA on rentre "joueur"
	 */
	private String niveau;
	
	
	/**
	 * attribut List<Territoire> listeTerritoires : liste des territoires possédés par le joueur
	 */
	private List<Territoire> listeTerritoires;
	
	
	//méthodes
	/**
	 * méthode attaquer
	 * @param territoireAttaquant : le territoire qui donne les pions pour attaquer, appartenant au joueur actif
	 * @param  nombrePion : nombre de pions lancés pour attaquer (compris entre 1 et 3)
	 * @param territoireDefenseur : territoire adjacent au territoire attaquant sur lequel l'attaque est lancée
	 */
	public void attaquer(Territoire territoireAttaquant, int nombrePion, Territoire territoireDefenseur) {
		
		//création d'une nouvelle liste de pion
		List<Pion> pionsDisponibles = new ArrayList<Pion>();
		
		//on parcourt tous les pions du territoire attaquant et on met dans la nouvelle liste ceux qui sont déplaçables
		for(int i=0; i < territoireAttaquant.getListePion().size(); i++) {
			if(territoireAttaquant.getListePion().get(i).isDeplacable()) {
				pionsDisponibles.add(territoireAttaquant.getListePion().get(i));
			}
		}
		
		//gestion des erreurs du joueur
		if(this.listeTerritoires.contains(territoireAttaquant)==false){
			System.out.println("Erreur : le territoire attaquant n'appartien pas au joueur");
		}
		
		else if(this.listeTerritoires.contains(territoireDefenseur)){
			System.out.println("Erreur : le territoire defenseur appartient au joueur");
		}
		
		else if(nombrePion>3) {
			System.out.println("Erreur : l'attanquant ne peut attaquer avec plus de 3 pions");
		}
		
		else if(territoireAttaquant.getListePion().size()<=nombrePion) {
			System.out.println("Erreur : il faut qu'il reste toujours au moins un pion sur le territoire attaquant");
		}
		
		else if(pionsDisponibles.size() < nombrePion){
			System.out.println("Erreur : il n'y a pas suffisement de pions disponible");
		}
		else if(territoireAttaquant.getListeTerritoiresAdjacents().contains(territoireDefenseur) == false) {
			System.out.println("Erreur : le territoire visé n'est pas adjacent au territoire attaquant");
		}
		
		else {
			//on va maintenant modéliser les dés pour savoir qui va gagner l'attaque
			//on utilise des nombres tirés au hasard entre 1 et 6 pour les dés
			//on initialise les listes vides qui vont contenir les valeurs des dés tirés
			List<Integer> desAttaquant = new ArrayList<Integer>();
			List<Integer> desDefenseur = new ArrayList<Integer>();
			
			//le joueur qui attaque peut lancer autant de dés que de pions qu'il utilise pour attaquer
			//donc entre 1 et 3
			System.out.println("Des Attaquants : ");
			for(int i=0; i<nombrePion; i++) {
				desAttaquant.add((int)(Math.random()*6+1));
				System.out.println(desAttaquant.get(i));
			}
			
			//le joueur qui est attaqué se défend avec un dé s'il a 1 seul pion sur le territoire et avec 2 dés 
			//si le défenseur en a plus
			System.out.println("Des Defenseurs : ");
			desDefenseur.add((int)(Math.random()*6+1));
			System.out.println(desDefenseur.get(0));
			if(territoireDefenseur.getListePion().size()>1) {
				desDefenseur.add((int)(Math.random()*6+1));
				System.out.println(desDefenseur.get(1));
			}
			
			//on va comparer les valeurs des dés les plus forts de l'attaquant et du défenseur
			int maxdesAttaquant=desAttaquant.get(0);
			int maxdesDefenseur=desDefenseur.get(0);
			
			for(int i = 0; i<desAttaquant.size(); i++) {
				if (maxdesAttaquant<desAttaquant.get(i)){
					maxdesAttaquant=desAttaquant.get(i);
				}
			}
			for(int i = 0; i<desDefenseur.size(); i++) {
				if (maxdesDefenseur<desDefenseur.get(i)){
					maxdesDefenseur=desDefenseur.get(i);
				}
			}
			if(maxdesAttaquant<=maxdesDefenseur) {
				//alors l'attaquant perd un pion, le 1er de la liste des pions convient
				territoireAttaquant.getListePion().remove(pionsDisponibles.get(0));
				System.out.println(this.nomJoueur+" a perdu un pion");
				
			}
			else{
				//alors c'est le défenseur qui perd un pion
				territoireDefenseur.getListePion().remove(territoireDefenseur.getListePion().get(0));
				System.out.println(territoireDefenseur.getPossesseur().getNomJoueur()+" a perdu un pion");
				if(territoireDefenseur.getListePion().size()==0) {
					territoireDefenseur.changePossesseur(this);
					this.deplacer(territoireAttaquant,nombrePion,territoireDefenseur);
					System.out.println(this.nomJoueur+" s'empare du territoire !");
				}
			}
						
		}
	}
	
	/**
	 * méthode deplacer, permet de déplacer des pions
	 *@param territoireDepart : territoire d'où partent les pions
	 *@param nombrePion : nombre de pions qui vont se déplacer ; doit être supérieur ou égal à 1, et il doit rester au moins un 
	 *pion sur territoireDepart
	 *@param territoireArrivee : territoire où vont être déplacés les pions. Doit appartenir au joueur actif 
	 */
	public void deplacer(Territoire territoireDepart, int nombrePion, Territoire territoireArrivee) {
		int nombrePionsDeplacable = territoireDepart.afficherNbPions();
		
		//gestion des erreurs
		if(nombrePion>=nombrePionsDeplacable){
			System.out.println("Erreur : pas assez de pions déplaçable");
		}
		
		else if(this.listeTerritoires.contains(territoireDepart)==false){
			System.out.println("Erreur : le territoire de départ n'appartien pas au joueur");
		}
		
		else if(this.listeTerritoires.contains(territoireArrivee)==false){
			System.out.println("Erreur : le territoire d'arrivée n'appartien pas au joueur");
		}
		
		else {
			//initialisation d'une variable pour le nombre de pions qu'on a déplacé. Tant qu'on n'est pas à 
			//nombrePion, on continue.
			
			int nbPionsDeplaces = 0;
				
			//on parcourt la liste à la recherche de pions déplaçables
			for(int i = 0; i < territoireDepart.getListePion().size(); i++) {
				
				//création d'une boucle while qui va tester si on a assez de pions déplaçables
				while (nbPionsDeplaces < nombrePion) {
					
					if(territoireDepart.getListePion().get(i).isDeplacable()) {
						territoireDepart.getListePion().get(i).deplacement(territoireArrivee);
						nbPionsDeplaces +=1;
					}
				}
				
		
			}
		}
	}
	

	
	
	/**
	 * méthode initialisationPions : rend tous les pions du joueur déplaçables
	 * Cette méthode pourra être utilisée à la fin d'un tour pour qu'au suivant, le joueur puisse jouer
	 */
	public void initialisationPions() {
		
		//on parcourt tous les territoires
		for(int territoire = 0; territoire < this.listeTerritoires.size(); territoire++) {
			//on parcourt tous les pions de chaque territoire
			for (int pions = 0; pions < this.listeTerritoires.get(territoire).getListePion().size(); pions++) {
				//on rend chaque pion déplaçable
				this.listeTerritoires.get(territoire).getListePion().get(pions).setDeplacable(true);
			}
		}
	}
	
	
	/**
	 * méthode renforts : ajoute un pion sur tous les territoires de listeTerritoire 
	 * @param listeTerritoire : liste des territoires appartenant au joueur où le joueur veut 
	 * placer un pion avec possibilité de doublon.
	 */
	public void renforts(List<Territoire> listeTerritoire) {
		for(int i=0; i<listeTerritoire.size(); i++) {
			Pion pion = new Pion(listeTerritoire.get(i));
			listeTerritoire.get(i).addPion(pion);
		}
	}	
	
	
	
	/**
	 * méthode finDeTour : permet de modéliser la fin d'un tour du joueur.
	 * 
	 */
	public void finTourJoueur() {
		//après que le joueur qui a joué ait indiqué "fin du tour", c'est la fin du tour du joueur on passe au joueur suivant

		//on vérifie si un joueur à été éliminé
		this.partie.verifierJoueurElimine();	
		List<Joueur> listeJoueurs = this.partie.getListeJoueurs();
		String joueurCourant = this.nomJoueur;//joueur courant
		String dernierJoueurListe = listeJoueurs.get(listeJoueurs.size()-1).getNomJoueur();//dernier joueur de la liste	
		//il faut vérifier qu'il ne reste pas qu'un seul joueur
		if (listeJoueurs.size()==1) {
			//la partie est finie, on renvoie à une autre méthode dans Partie
			System.out.println("Un seul joueur restant !");
			System.out.println("Le gagnant est : "+this.nomJoueur);
			this.partie.setEnCours(false);
		}
		
		//si le dernier joueur de la liste est le joueur courant, tous les joueurs ont joué une fois, le tour de plateau est fini.
		else if (dernierJoueurListe == joueurCourant) {
			
			//il faut vérifier qu'on n'est pas au dernier tour de partie, sinon on renvoie à d'autres méthodes
			if (this.partie.getNbTours() == this.partie.getNbToursMax()) {
				//la partie est finie, on renvoie à une méthode dans partie qui détermine le gagnant
				System.out.println("Nombre de tour max atteind");
				Joueur gagnant = this;
				for(Joueur joueur : this.partie.getListeJoueurs()) {
					System.out.println(joueur.getNomJoueur()+" posséde "+joueur.getListeTerritoires().size()+" territoires.");
					if(joueur.getListeTerritoires().size()>gagnant.getListeTerritoires().size()) {
						gagnant = joueur;
					}
				}
				this.partie.setEnCours(false);
			}
			
			else {//la partie n'est pas finie mais le tour de plateau est fini
				this.partie.setNbTours(this.partie.getNbTours()+1); //on fait +1 au nombre de tours de plateau
				//joueur courant : joueur n°1 de la liste
				this.partie.setJoueurActif(listeJoueurs.get(0));	
			}
		}
		else {//le tour de plateau n'est pas fini
			
			//on récupère le n° du joueur actif
			int numero = listeJoueurs.indexOf(this.partie.getJoueurActif());
			System.out.println(numero);
			//on passe au joueur suivant
			this.partie.setJoueurActif(listeJoueurs.get(numero+1));			
		}
	}
	
	
	/**
	 * méthode calculerRenfort : permet de calculer le nombre de pions attribués au joueur actif en début de tour, en fonction
	 * de ses territoires.
	 * @return nombre de renforts du joueur actif.
	 */
	public int calculerNbRenfort() {
		int renforts = 0;
		//Le joueur reçoit 1 renfort pour 3 territoires arrondis à l'entier inférieur.
		renforts = renforts +(int)(listeTerritoires.size()/3);
		//Le joueur reçoit un bonus s'il contrôle un continent.
		for(Continent continent : this.partie.getListeContinents()) {
			if (continent.verifPossession(this.partie.getJoueurActif())) {
				renforts = renforts + continent.getNbRenfort();
			}
		}
		if(renforts<3) {
			renforts =3;
		}
		return(renforts);
	}
	
	/**
	 * méthode addTerritoire : va ajouter un territoire à la liste des territoires d'un joueur
	 * @param territoire : le territoire qu'on veut ajouter
	 */
	public void addTerritoire(Territoire territoire) {
		this.listeTerritoires.add(territoire);
	}
	
	/**
	 * m�thode isIa : indique si le joueur est une iA
	 * @return : true si c'est une ia, false sinon
	 */
	public boolean isIa() {
		return(this.iA);
	}
	

	/**
	 * méthode renfortIA : permet de placer les renforts selon le niveau de l'intelligence artificielle
	 * @param nbRenforts : nombre de renforts qu'on veut placer
	 */
	public void renfortIA(int nbRenforts) {
		
		//initialisation du nombre de pions placés
		int pionsPlaces = 0;
		
		//if (this.niveau == "niveau0") {
		if (this.niveau.compareTo("niveau0")==0) {
			//alors l'intelligence artificielle agit de manière aléatoire pour placer les renforts
			
			//on initialise une variable du nombre de renforts placés 
			int nbRenfortsPlaces = 0;
			while (nbRenfortsPlaces < nbRenforts) {
				//on crée un nombre aléatoire entre 0 et tailleListe-1 qui va correspondre à l'indice aléatoire	
				int nbAlea = (int) (Math.random()*this.listeTerritoires.size());
				
				//on crée un nouveau Pion
				Pion pion = new Pion(this.listeTerritoires.get(nbAlea));
				this.listeTerritoires.get(nbAlea).addPion(pion);
				nbRenfortsPlaces = nbRenfortsPlaces  + 1;
				
				
			}
		}
		//IA de niveau 1 : on ne place un renfort que si le territoire tiré au hasard est au contact d'un territoire d'un autre joueur.
		else if(this.niveau == "niveau1"){
			while(pionsPlaces<nbRenforts){
				int numTerritoire = (int)(Math.random()*this.listeTerritoires.size());			
				if(this.listeTerritoires.get(numTerritoire).isTerritoireFrontalier()){
					Pion pion = new Pion(this.listeTerritoires.get(numTerritoire));
					this.listeTerritoires.get(numTerritoire).addPion(pion);
					pionsPlaces=pionsPlaces+1;
				}			
			}
		}
		
		//IA de niveau 2 : on place les renforts sur les territoires frontaliers en fonction du nombre de territoires ennemis au contact.
		if(this.niveau=="niveau2"){
			List<Territoire> territoiresFrontaliers = new ArrayList<Territoire>(); //comporte le liste des territoires frontaliers, chaque territoires apparait autant de fois qu'il a de territoires ennemis au contact
			for(Territoire territoire : this.listeTerritoires){
				if(territoire.isTerritoireFrontalier()){
					for(int k=0; k<territoire.TerritoiresEnnemisAdjacents().size(); k++){
						System.out.println("territoiresFrontaliers renf"+territoire.getNom());
						territoiresFrontaliers.add(territoire);
					}
				}
			}
			while(pionsPlaces<nbRenforts){  //on place les renforts aléatoirement sur les territoires de territoiresFrontaliers.
				int numTerritoire = (int)(Math.random()*territoiresFrontaliers.size());
				Pion pion = new Pion(territoiresFrontaliers.get(numTerritoire));
				territoiresFrontaliers.get(numTerritoire).addPion(pion);
				pionsPlaces=pionsPlaces+1;
			}
		}
		
	}
	
	/**
	 * méthode attaqueIA : permet de modéliser l'attaque d'une IA
	 */
	public void attaqueIA(){
		System.out.println("attaqueIa");
		
		int pionsAttaquants;
		int pionsDefenseurs;

		//IA de niveau 0 : on attaque dès que l'on peut
		if(this.niveau== "niveau0"){
			
			//on parcourt tous les territoires appartenant au joueur, on va attaquer avec tous les territoires disponibles
			List<Territoire> listeTerritoiresJoueur = new ArrayList<Territoire>();
			
			//on fait une copie de la liste 
			for(int i = 0; i<this.listeTerritoires.size();i++) {
				listeTerritoiresJoueur.add(this.listeTerritoires.get(i));
			}
			
			for(Territoire territoire : listeTerritoiresJoueur){
				
				//on initialise une variable pionsDisponibles qui va modéliser le nombre de pions avec lesquels on peut attaquer
				int pionsDisponibles = territoire.pionsDisponibles();
				
				while(pionsDisponibles>0){
					
					//on regarde s'il y a des territoires ennemis adjacents pour les attaquer
					if(territoire.TerritoiresEnnemisAdjacents().size()>0) {
						
						//on parcourt lesdits territoires
						for(Territoire territoireAdjacent : territoire.TerritoiresEnnemisAdjacents()){
							if(pionsDisponibles<4){
								pionsAttaquants = pionsDisponibles;
								//on attaque avec tous les pions disponibles
							}
							else{
								pionsAttaquants = 3;
							}
							//on utilise la fonction attaquer qu'on a déjà codé
							
							if(pionsAttaquants>0) {
								attaquer(territoire,pionsAttaquants,territoireAdjacent);
								pionsDisponibles = territoire.pionsDisponibles();
							}	
						}
					}
					else {
						pionsDisponibles = 0;
					}
				}

			}
		}
		//IA de niveau 1 : on attaque que si la bataille comporte plus d'attaquant que de defenseur
		else if(this.niveau == "niveau1"){
			
			//on parcourt tous les territoires appartenant au joueur, on va attaquer avec tous les territoires disponibles
			List<Territoire> listeTerritoiresJoueur = new ArrayList<Territoire>();
			
			//on fait une copie de la liste 
			for(int i = 0; i<this.listeTerritoires.size();i++) {
				listeTerritoiresJoueur.add(this.listeTerritoires.get(i));
			}
			
			for(Territoire territoire : listeTerritoiresJoueur){
				int pionsDisponiblesAttaquant = territoire.pionsDisponibles();
				if(pionsDisponiblesAttaquant >0){
					if(territoire.TerritoiresEnnemisAdjacents().size()>0) {
						for(Territoire territoireAdjacent : territoire.TerritoiresEnnemisAdjacents()){
							if(pionsDisponiblesAttaquant<4){
								pionsAttaquants = pionsDisponiblesAttaquant;
							}
							else{
								pionsAttaquants = 3;
							}
									
							if(territoireAdjacent.getListePion().size()<2){
								pionsDefenseurs = territoireAdjacent.getListePion().size();
							}
							else{
								pionsDefenseurs = 2;
							}
							while(pionsAttaquants > pionsDefenseurs){
								if(territoireAdjacent.getPossesseur().getNomJoueur().compareTo(this.nomJoueur)!=0) {
									attaquer(territoire,pionsAttaquants,territoireAdjacent);
									pionsDisponiblesAttaquant = territoire.pionsDisponibles();
									if(pionsDisponiblesAttaquant<4){
										pionsAttaquants = pionsDisponiblesAttaquant;
									}
									else{
										pionsAttaquants = 3;
									}
								}
								else {
									pionsAttaquants=0;
								}
								
							}
							
						}
					}
				}
			}
		}
		
		//IA de niveau 2 : on attaque que si la bataille comporte plus d'attaquant que de defenseur et on se garde une reserve proportionelle au nombre de territoires
		// hostiles au contact
		else if(this.niveau== "niveau2"){
			
			//on parcourt tous les territoires appartenant au joueur, on va attaquer avec tous les territoires disponibles
			List<Territoire> listeTerritoiresJoueur = new ArrayList<Territoire>();
			
			//on fait une copie de la liste 
			for(int i = 0; i<this.listeTerritoires.size();i++) {
				listeTerritoiresJoueur.add(this.listeTerritoires.get(i));
			}
			
			for(Territoire territoire : listeTerritoiresJoueur){
				int reserve = territoire.TerritoiresEnnemisAdjacents().size()*2; //nombre de pions que l'on souhaite garder en reserve é la fin du tour
				int pionsDisponibles = territoire.pionsDisponibles();		//nombre de pions qui peuvent attaquer
				int nbPionsTotal = territoire.getListePion().size();
				int pionsDisponiblesAttaquants;
				if(nbPionsTotal-pionsDisponibles>reserve){
					 pionsDisponiblesAttaquants = territoire.pionsDisponibles();
				}		
				else{
					pionsDisponiblesAttaquants = nbPionsTotal-reserve;    
				}	
				if(pionsDisponiblesAttaquants >0){
					for(Territoire territoireAdjacent : territoire.getListeTerritoiresAdjacents()){
						if(territoireAdjacent.getPossesseur() != territoire.getPossesseur()){
							if(pionsDisponiblesAttaquants<4){
								pionsAttaquants = pionsDisponiblesAttaquants;
							}
							else{
								pionsAttaquants = 3;
							}

							
							if(territoireAdjacent.getListePion().size()<2){
								pionsDefenseurs = territoireAdjacent.getListePion().size();
							}
							else{
								pionsDefenseurs = 2;
							}
							while(pionsAttaquants > pionsDefenseurs){
								if(territoireAdjacent.getPossesseur().getNomJoueur().compareTo(this.nomJoueur)!=0) {
									attaquer(territoire,pionsAttaquants,territoireAdjacent);
									pionsDisponiblesAttaquants = territoire.pionsDisponibles();
									if(pionsDisponiblesAttaquants<4){
										pionsAttaquants = pionsDisponiblesAttaquants;
									}
									else{
										pionsAttaquants = 3;
									}
								}
								else {
									pionsAttaquants=0;
								}
								
							}
						}
					}
				}
			}
		}
		System.out.println("finAttaqueIa");
	}
	
	
	/**
	 * m�thode deplacementIA : permet de mod�liser le d�placement de pions d'une intelligence artificielle
	 */
	public void deplacementIA(){
		System.out.println("deplacementIa");
		
		//IA de niveau 0 : si un territoire n'a pas de territoires ennemis adjacent alors les troupes se déplacent aléatoirement.
		if(this.niveau == "niveau0"){
			for(Territoire territoire : this.listeTerritoires){	
				int territoireDispo = territoire.pionsDisponibles();
				while(territoireDispo > 0){
					if (territoire.isTerritoireFrontalier() == false){
						
							int numTerritoireDestination = (int)(Math.random()*territoire.getListeTerritoiresAdjacents().size());
							this.deplacer(territoire,1,territoire.getListeTerritoiresAdjacents().get(numTerritoireDestination));
							territoireDispo = territoire.pionsDisponibles();
						
					}
					else {
						territoireDispo = 0;
					}
				}
			}
		}
		
		//IA de niveau 1 : si un territoire n'a pas de territoires ennemis adjacent alors on déplace les troupes vers des territoires adjacents qui en ont
		// sinon les troupes se déplacent aléatoirement.
		if(this.niveau == "niveau1"){
			for(Territoire territoire : this.listeTerritoires){	
				int territoireDispo = territoire.pionsDisponibles();
				while(territoireDispo > 0){
					if (territoire.isTerritoireFrontalier() == false){
						//si le territoire n'est pas frontalier on recherche dans ses voisins des territoires qui sont frontaliers pour leur envoyer des troupes
						//si il n'y en as pas le déplacement est aléatoire.
						List<Territoire> listeTerritoireAdjacentsFrontaliers = territoire.listeTerritoireAdjacentsFrontaliers();
						if(listeTerritoireAdjacentsFrontaliers.size()>0){
							int numTerritoireDestination = (int)(Math.random()*listeTerritoireAdjacentsFrontaliers.size());
							this.deplacer(territoire,1,listeTerritoireAdjacentsFrontaliers.get(numTerritoireDestination));
							territoireDispo = territoire.pionsDisponibles();
						}
						else{
							int numTerritoireDestination = (int)(Math.random()*territoire.getListeTerritoiresAdjacents().size());
							this.deplacer(territoire,1,territoire.getListeTerritoiresAdjacents().get(numTerritoireDestination));
							territoireDispo = territoire.pionsDisponibles();
						}
					}
					else {
						territoireDispo = 0;
					}
				}
			}
		}

		//IA de niveau 2 :si un territoire n'a pas de territoires ennemis adjacents alors on déplace les troupes vers des territoires adjacents qui en ont
		// sinon les troupes se déplacent vers le territoire frontalier le plus proche.
		// Cette portion de code ne marche pas parfaitement donc on la remplace par le d�placement de niveau1.
		if(this.niveau == "niveau2"){
			for(Territoire territoire : this.listeTerritoires){	
				int territoireDispo = territoire.pionsDisponibles();
				while(territoireDispo > 0){
					if (territoire.isTerritoireFrontalier() == false){
						//si le territoire n'est pas frontalier on recherche dans ses voisins des territoires qui sont frontaliers pour leur envoyer des troupes
						//si il n'y en as pas le déplacement est aléatoire.
						List<Territoire> listeTerritoireAdjacentsFrontaliers = territoire.listeTerritoireAdjacentsFrontaliers();
						if(listeTerritoireAdjacentsFrontaliers.size()>0){
							int numTerritoireDestination = (int)(Math.random()*listeTerritoireAdjacentsFrontaliers.size());
							this.deplacer(territoire,1,listeTerritoireAdjacentsFrontaliers.get(numTerritoireDestination));
							territoireDispo = territoire.pionsDisponibles();
						}
						else{
							int numTerritoireDestination = (int)(Math.random()*territoire.getListeTerritoiresAdjacents().size());
							this.deplacer(territoire,1,territoire.getListeTerritoiresAdjacents().get(numTerritoireDestination));
							territoireDispo = territoire.pionsDisponibles();
						}
					}
					else {
						territoireDispo = 0;
					}
				}
			}
		}
		System.out.println("finDeplacementIa");
	}
	
	
	/**
	 * constructeur de la classe Joueur
	 * méthode Joueur : permet de créer un joueur
	 * @param nomJoueur : le nom du joueur en question
	 * @param niveau : niveau de l'intelligence artificielle souhait�
	 * @param partie : la partie
	 */
	public Joueur(String nomJoueur, String niveau, Partie partie) {
		this.nomJoueur = nomJoueur;
		if (niveau == "joueur") {
			this.iA = false;
		}
		else {
			this.iA = true;
		}
		this.listeTerritoires = new ArrayList<>();
		this.partie = partie;
		this.niveau = niveau;
	}
	
	/**
	 * m�thode territoirePossede : permet de savoir si le territoire consid�r� appartient au Joueur
	 * @param nomTerritoire : nom du territoire dont on veut vérifier le possesseur
	 * @return true si le territoire appartient au joueur, false sinon
	 */
	public boolean territoirePossede(String nomTerritoire) {
		for (Territoire territoire : this.listeTerritoires) {
			if(territoire.getNom().compareTo(nomTerritoire)==0) {
				return(true);
			}			
		}
		return(false);
	}
	
	
	//getter et setter
	
	/**
	 * getter
	 * méthode getNomJoueur : permet d'obtenir le nom du joueur
	 * @return nomJoueur : le nom du joueur
	 */
	public String getNomJoueur() {
		return nomJoueur;
	}

	/**
	 * setter
	 * méthode setNomJoueur : permet de modifier le nom du joueur
	 * @param nomJoueur : le nouveau nom du joueur
	 */
	public void setNomJoueur(String nomJoueur) {
		this.nomJoueur = nomJoueur;
	}

	/**
	 * getter
	 * méthode getListeTerritoires : permet d'obtenir la liste des territoires d'un joueur
	 * @return listeTerritoires : ladite liste
	 */
	public List<Territoire> getListeTerritoires() {
		return listeTerritoires;
	}
	
	/**
	 * getter
	 * m�thode getCouleur : permet d'avoir acc�s � la couleur du joueur
	 * @return : ladite couleur 
	 */
	public Color getCouleur() {
		return couleur;
	}
	/**
	 * setter
	 * m�thode setCouleur : permet de changer la couleur d'un joueur
	 * @param couleur : la couleur qu'on veut mettre
	 */
	public void setCouleur(Color couleur) {
		this.couleur = couleur;
	}
	
	
	
	
}
