package risk;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import io.Fenetre;
import io.FondDeCarte;


import java.util.List;

/**
 * classe Main : permet d'ex�cuter le programme
 * @author fau_kinuk_toussaint
 *
 */
public class Main {

	/**
	 * m�thode main
	 * @param args : arguments
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		// --- Interface Settings ---
		//param�tres en d�but de partie
		Partie partie = new Partie();
		
		//d�tails fen�tre param�tres
		JFrame fenetreSetting = new JFrame();
		fenetreSetting.setTitle("Risk Settup");
		fenetreSetting.setSize(600,730);
		fenetreSetting.setLocationRelativeTo(null);
		fenetreSetting.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fenetreSetting.setVisible(true);
		
		JPanel panneauSetting = new JPanel();
		panneauSetting.setLayout(null);
		
		// --> Combobox nb joueur
		
		JLabel lbl3 = new JLabel("Nombre de joueurs : ");
		lbl3.setBounds(10,10,490,40);
		lbl3.setFont(new Font("Arial", Font.BOLD, 24));
		panneauSetting.add(lbl3);
		
		
		JComboBox<Integer> nbJoueur = new JComboBox<Integer>();
		nbJoueur.addItem(2);
		nbJoueur.addItem(3);
		nbJoueur.addItem(4);
		nbJoueur.addItem(5);
		nbJoueur.addItem(6);
		nbJoueur.setBounds(250,10,90,40);
		nbJoueur.setFont(new Font("Arial", Font.PLAIN, 18));
		panneauSetting.add(nbJoueur);
		
		// --> Cadres nomJoueur
		JTextField nomjoueur1 = new JTextField();
		nomjoueur1.setBounds(10,75,350,40);
		nomjoueur1.setFont(new Font("Arial", Font.BOLD, 24));
		panneauSetting.add(nomjoueur1);
		
		JTextField nomjoueur2 = new JTextField();
		nomjoueur2.setBounds(10,125,350,40);
		nomjoueur2.setFont(new Font("Arial", Font.BOLD, 24));
		panneauSetting.add(nomjoueur2);
		
		JTextField nomjoueur3 = new JTextField();
		nomjoueur3.setBounds(10,175,350,40);
		nomjoueur3.setFont(new Font("Arial", Font.BOLD, 24));
		panneauSetting.add(nomjoueur3);
		
		JTextField nomjoueur4 = new JTextField();
		nomjoueur4.setBounds(10,225,350,40);
		nomjoueur4.setFont(new Font("Arial", Font.BOLD, 24));
		panneauSetting.add(nomjoueur4);
		
		JTextField nomjoueur5 = new JTextField();
		nomjoueur5.setBounds(10,275,350,40);
		nomjoueur5.setFont(new Font("Arial", Font.BOLD, 24));
		panneauSetting.add(nomjoueur5);
		
		JTextField nomjoueur6 = new JTextField();
		nomjoueur6.setBounds(10,325,350,40);
		nomjoueur6.setFont(new Font("Arial", Font.BOLD, 24));
		panneauSetting.add(nomjoueur6);
		
		// --> Comboboxs IA/Humain
		
		JComboBox<String> typeJoueur1 = new JComboBox<String>();
		typeJoueur1.addItem("joueur");
		typeJoueur1.addItem("niveau0");
		typeJoueur1.addItem("niveau1");
		typeJoueur1.addItem("niveau2");
		typeJoueur1.setBounds(360,75,90,40);
		typeJoueur1.setFont(new Font("Arial", Font.PLAIN, 24));
		panneauSetting.add(typeJoueur1);
		
		JComboBox<String> typeJoueur2 = new JComboBox<String>();
		typeJoueur2.addItem("joueur");
		typeJoueur2.addItem("niveau0");
		typeJoueur2.addItem("niveau1");
		typeJoueur2.addItem("niveau2");
		typeJoueur2.setBounds(360,125,90,40);
		typeJoueur2.setFont(new Font("Arial", Font.PLAIN, 24));
		panneauSetting.add(typeJoueur2);
		
		JComboBox<String> typeJoueur3 = new JComboBox<String>();
		typeJoueur3.addItem("joueur");
		typeJoueur3.addItem("niveau0");
		typeJoueur3.addItem("niveau1");
		typeJoueur3.addItem("niveau2");
		typeJoueur3.setBounds(360,175,90,40);
		typeJoueur3.setFont(new Font("Arial", Font.PLAIN, 24));
		panneauSetting.add(typeJoueur3);
		
		JComboBox<String> typeJoueur4 = new JComboBox<String>();
		typeJoueur4.addItem("joueur");
		typeJoueur4.addItem("niveau0");
		typeJoueur4.addItem("niveau1");
		typeJoueur4.addItem("niveau2");
		typeJoueur4.setBounds(360,225,90,40);
		typeJoueur4.setFont(new Font("Arial", Font.PLAIN, 24));
		panneauSetting.add(typeJoueur4);
		
		JComboBox<String> typeJoueur5 = new JComboBox<String>();
		typeJoueur5.addItem("joueur");
		typeJoueur5.addItem("niveau0");
		typeJoueur5.addItem("niveau1");
		typeJoueur5.addItem("niveau2");
		typeJoueur5.setBounds(360,275,90,40);
		typeJoueur5.setFont(new Font("Arial", Font.PLAIN, 24));
		panneauSetting.add(typeJoueur5);
		
		JComboBox<String> typeJoueur6 = new JComboBox<String>();
		typeJoueur6.addItem("joueur");
		typeJoueur6.addItem("niveau0");
		typeJoueur6.addItem("niveau1");
		typeJoueur6.addItem("niveau2");
		typeJoueur6.setBounds(360,325,90,40);
		typeJoueur6.setFont(new Font("Arial", Font.PLAIN, 24));
		panneauSetting.add(typeJoueur6);
		
		// --> Combobox nb tour
		
		JLabel lbl4 = new JLabel("Nombre de tours : ");
		lbl4.setBounds(10,380,490,40);
		lbl4.setFont(new Font("Arial", Font.BOLD, 24));
		panneauSetting.add(lbl4);
		
		JComboBox<Integer> nbTours = new JComboBox<Integer>();
		nbTours.addItem(10);
		nbTours.addItem(25);
		nbTours.addItem(50);
		nbTours.setBounds(225,380,90,40);
		nbTours.setFont(new Font("Arial", Font.PLAIN, 18));
		panneauSetting.add(nbTours);
		
		// --> Cadre chemin d'acces fichier
		JLabel lbl5 = new JLabel("Chemin d'accès map : ");
		lbl5.setBounds(10,440,490,40);
		lbl5.setFont(new Font("Arial", Font.BOLD, 24));
		panneauSetting.add(lbl5);
		
		JTextField path = new JTextField();
		path.setBounds(280,440,310,40);
		path.setFont(new Font("Arial", Font.BOLD, 24));
		panneauSetting.add(path);
		
		// --> Bouton LancerPartie
		 
		JButton run = new JButton("Lancer Partie");
		run.setBounds(10,490,580,200);
		run.setMargin(new Insets(0,0,0,0));
		run.setFont(new Font("Arial", Font.PLAIN, 60));
		run.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
	            partie.setEnCours(true);;  
	        }  
	    });
		panneauSetting.add(run);
		
		fenetreSetting.setContentPane(panneauSetting);
		fenetreSetting.revalidate();
		fenetreSetting.repaint();
		
		while (partie.isEnCours() == false) {
			System.out.print("");
		}
		
		// --- --- --- --- --- --- ---
		
		
		partie.setNbToursMax((int) nbTours.getSelectedItem());
		String path_map = (String) path.getText();
		if ((int) nbJoueur.getSelectedItem() == 2) {
			Joueur joueur1 = new Joueur((String)nomjoueur1.getText(),(String) typeJoueur1.getSelectedItem(),partie);
			Joueur joueur2 = new Joueur((String)nomjoueur2.getText(),(String) typeJoueur2.getSelectedItem(),partie);
			joueur1.setCouleur(Color.RED);
			joueur2.setCouleur(Color.BLUE);
			partie.addJoueur(joueur1);
			partie.addJoueur(joueur2);
		}
		
		if ((int) nbJoueur.getSelectedItem() == 3) {
			Joueur joueur1 = new Joueur((String)nomjoueur1.getText(),(String) typeJoueur1.getSelectedItem(),partie);
			Joueur joueur2 = new Joueur((String)nomjoueur2.getText(),(String) typeJoueur2.getSelectedItem(),partie);
			Joueur joueur3 = new Joueur((String)nomjoueur3.getText(),(String) typeJoueur3.getSelectedItem(),partie);
			joueur1.setCouleur(Color.RED);
			joueur2.setCouleur(Color.BLUE);
			joueur3.setCouleur(Color.GREEN);
			partie.addJoueur(joueur1);
			partie.addJoueur(joueur2);
			partie.addJoueur(joueur3);
		}	
		
		if ((int) nbJoueur.getSelectedItem() == 4) {
			Joueur joueur1 = new Joueur((String)nomjoueur1.getText(),(String) typeJoueur1.getSelectedItem(),partie);
			Joueur joueur2 = new Joueur((String)nomjoueur2.getText(),(String) typeJoueur2.getSelectedItem(),partie);
			Joueur joueur3 = new Joueur((String)nomjoueur3.getText(),(String) typeJoueur3.getSelectedItem(),partie);
			Joueur joueur4 = new Joueur((String)nomjoueur4.getText(),(String) typeJoueur4.getSelectedItem(),partie);
			joueur1.setCouleur(Color.RED);
			joueur2.setCouleur(Color.BLUE);
			joueur3.setCouleur(Color.GREEN);
			joueur4.setCouleur(Color.YELLOW);
			partie.addJoueur(joueur1);
			partie.addJoueur(joueur2);
			partie.addJoueur(joueur3);
			partie.addJoueur(joueur4);
		}
		
		if ((int) nbJoueur.getSelectedItem() == 5) {
			Joueur joueur1 = new Joueur((String)nomjoueur1.getText(),(String) typeJoueur1.getSelectedItem(),partie);
			Joueur joueur2 = new Joueur((String)nomjoueur2.getText(),(String) typeJoueur2.getSelectedItem(),partie);
			Joueur joueur3 = new Joueur((String)nomjoueur3.getText(),(String) typeJoueur3.getSelectedItem(),partie);
			Joueur joueur4 = new Joueur((String)nomjoueur4.getText(),(String) typeJoueur4.getSelectedItem(),partie);
			Joueur joueur5 = new Joueur((String)nomjoueur5.getText(),(String) typeJoueur5.getSelectedItem(),partie);
			joueur1.setCouleur(Color.RED);
			joueur2.setCouleur(Color.BLUE);
			joueur3.setCouleur(Color.GREEN);
			joueur4.setCouleur(Color.YELLOW);
			joueur5.setCouleur(Color.PINK);
			partie.addJoueur(joueur1);
			partie.addJoueur(joueur2);
			partie.addJoueur(joueur3);
			partie.addJoueur(joueur4);
			partie.addJoueur(joueur5);
		}
		
		if ((int) nbJoueur.getSelectedItem() == 6) {
			Joueur joueur1 = new Joueur((String)nomjoueur1.getText(),(String) typeJoueur1.getSelectedItem(),partie);
			Joueur joueur2 = new Joueur((String)nomjoueur2.getText(),(String) typeJoueur2.getSelectedItem(),partie);
			Joueur joueur3 = new Joueur((String)nomjoueur3.getText(),(String) typeJoueur3.getSelectedItem(),partie);
			Joueur joueur4 = new Joueur((String)nomjoueur4.getText(),(String) typeJoueur4.getSelectedItem(),partie);
			Joueur joueur5 = new Joueur((String)nomjoueur5.getText(),(String) typeJoueur5.getSelectedItem(),partie);
			Joueur joueur6 = new Joueur((String)nomjoueur6.getText(),(String) typeJoueur6.getSelectedItem(),partie);
			joueur1.setCouleur(Color.RED);
			joueur2.setCouleur(Color.BLUE);
			joueur3.setCouleur(Color.GREEN);
			joueur4.setCouleur(Color.YELLOW);
			joueur5.setCouleur(Color.PINK);
			joueur6.setCouleur(Color.ORANGE);
			partie.addJoueur(joueur1);
			partie.addJoueur(joueur2);
			partie.addJoueur(joueur3);
			partie.addJoueur(joueur4);
			partie.addJoueur(joueur5);
			partie.addJoueur(joueur6);
		}
		
		

		
		//initialisation carte
		
		ImportCarte importation = new ImportCarte();
		List<List<String>> data = new ArrayList();
		data = importation.importerCarte(path_map);
		importation.creationContinents(data.get(0), partie);
		importation.creationTerritoires(data.get(1), partie);
		importation.creationFrontiere(data.get(1), data.get(2), partie);
		
		//--- Ajout Interface ---
		
		FondDeCarte fondDeCarte = new FondDeCarte(importation.importerFondDeCarte(path_map));
		Fenetre fenetre = new Fenetre();
		
		// Bouton Attaquer
		JButton bt1 = new JButton("Attaquer");
		bt1.setBounds(30,300,100,40);
		bt1.setMargin(new Insets(0,0,0,0));
		bt1.setFont(new Font("Arial", Font.PLAIN, 18));
		bt1.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
	            partie.setActionJoueur("attaquer");;  
	        }  
	    });
		fondDeCarte.add(bt1);
		
		// Bouton Déplacer
		JButton bt2 = new JButton("Déplacer");
		bt2.setBounds(30,350,100,40);
		bt2.setMargin(new Insets(0,0,0,0));
		bt2.setFont(new Font("Arial", Font.PLAIN, 18));
		bt2.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
	            partie.setActionJoueur("deplacer");;  
	        }  
	    });
		fondDeCarte.add(bt2);
		
		// Bouton Fin De Tour
		JButton bt3 = new JButton("Fin de tour");
		bt3.setBounds(30,400,100,40);
		bt3.setMargin(new Insets(0,0,0,0));
		bt3.setFont(new Font("Arial", Font.PLAIN, 18));
		bt3.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
	            partie.setActionJoueur("fin du tour");;  
	        }  
	    });
		fondDeCarte.add(bt3);
		
		// Boite Selection Nombre de Troupe
		JComboBox<Integer> nbTroupe = new JComboBox<Integer>();
		nbTroupe.addItem(1);
		nbTroupe.addItem(2);
		nbTroupe.addItem(3);
		nbTroupe.setBounds(140,325,40,50);
		nbTroupe.setFont(new Font("Arial", Font.PLAIN, 18));
		fondDeCarte.add(nbTroupe);
		
		// Label Joueur Actif
		JLabel lbl1 = new JLabel("Joueur Actif : ");
		lbl1.setBounds(750,10,300,100);
		lbl1.setFont(new Font("Arial", Font.BOLD, 24));
		fondDeCarte.add(lbl1);
		
		// Label Info / Debug
		JLabel lbl2 = new JLabel("Console : ");
		lbl2.setBounds(950,925,800,100);
		lbl2.setFont(new Font("Arial", Font.PLAIN, 24));
		fondDeCarte.add(lbl2);
		
		// Création Bouton et Label Territoire
		importation.creationBouton(data.get(3),fondDeCarte,partie);
		
		fenetre.setContentPane(fondDeCarte);
		fenetre.revalidate();
		fenetre.repaint();		

		// --- --- --- --- ---
		


		partie.lancerPartie();
		
		for(Continent c : partie.getListeContinents()) {
			for(Territoire t : c.getListeTerritoires()) {
				t.update();
			}
		}	
		
		//Renfort initial
		//Chaque joueur doit placer des renforts en début de partie
		System.out.println("Phase de renfort de début de partie, chaque joueur a "+partie.getJoueurActif().getListeTerritoires().size()+" pions à placer."+"\n");
		for(int joueur = 0; joueur<partie.getNbJoueurs();joueur++) {
			lbl1.setText("Joueur Actif : " + partie.getListeJoueurs().get(joueur).getNomJoueur());      // [ Interface ]
			lbl1.setForeground(partie.getListeJoueurs().get(joueur).getCouleur());                      // [ Interface ]
			if(partie.getListeJoueurs().get(joueur).isIa()==false) {
				int nbPionPlace =0;
				while(nbPionPlace<partie.getListeJoueurs().get(0).getListeTerritoires().size()) {
					String nomTerritoire = "";
					boolean territoirePossede = false;
					while (territoirePossede==false) { //on reste dans la boucle tant que le joueur ne donne pas le nom d'un territoire qu'il possède
						List<Territoire> listeTerritoire = new ArrayList<>(); // liste des territoires où le joueur veut placer un pion (possibilité de doublon)
						partie.etatPlateau();
						System.out.println(partie.getListeJoueurs().get(joueur).getNomJoueur()+" : entrez le nom du territoire de destination.");
						//String nomTerritoire = sc.nextLine();
						// Interface ---
						partie.waitSelecTerritoire();
						nomTerritoire = partie.getTerritoireSelectionee().getNom();
						// Interface ---
						//on vérifie si le territoire appartient bien au joueur
						for(int i=0; i < partie.getListeJoueurs().get(joueur).getListeTerritoires().size(); i++) {
							if(partie.getListeJoueurs().get(joueur).getListeTerritoires().get(i).getNom().compareTo(nomTerritoire)==0){
								Territoire territoire = partie.getListeJoueurs().get(joueur).getListeTerritoires().get(i);
								territoirePossede = true ;
								listeTerritoire.add(territoire);
								//on place les pions
								partie.getListeJoueurs().get(joueur).renforts(listeTerritoire);
								territoire.update();     // [Interface]
								System.out.println("pion placé");
								nbPionPlace = nbPionPlace +1;
							}	
						}
						if(territoirePossede==false) {
							System.out.println("Erreur :le territoire de destination n'appartient pas au joueur");
						}
					}
				}
			}
			else{
				partie.getListeJoueurs().get(joueur).renfortIA(partie.getListeJoueurs().get(0).getListeTerritoires().size());
				for(Continent c : partie.getListeContinents()) {
					for(Territoire t : c.getListeTerritoires()) {
						t.update();
					}
				}
			}
		}
		
		
		while(partie.isEnCours()) { //on reste dans la boucle tant que la partie n'est pas finie
			
			//tour  du joueur
			System.out.println("Au tour de "+partie.getJoueurActif().getNomJoueur()+"\n");
			lbl1.setText("Joueur Actif : " + partie.getJoueurActif().getNomJoueur());      // [ Interface ]
			lbl1.setForeground(partie.getJoueurActif().getCouleur());                      // [ Interface ]
		
			
			//Renfort début de tour
			System.out.println("Phase de renfort");
			if(partie.getJoueurActif().isIa()) {
				partie.getJoueurActif().renfortIA(partie.getJoueurActif().calculerNbRenfort());
				for(Continent c : partie.getListeContinents()) {
					for(Territoire t : c.getListeTerritoires()) {
						t.update();
					}
				}
			}
			else {	
				int nbPionPlace =0;
				while(nbPionPlace<partie.getJoueurActif().calculerNbRenfort()) { 
					String nomTerritoire = "";
					System.out.println("Nombre de pions restants à placer : "+(partie.getJoueurActif().calculerNbRenfort() - nbPionPlace));
					boolean territoirePossede = false;
					while (territoirePossede==false) {  //on reste dans la boucle tant que le joueur ne donne pas le nom d'un territoire qu'il possède
						List<Territoire> listeTerritoire = new ArrayList<>();// liste des territoires où le joueur veut placer un pion (possibilité de doublon)
						partie.etatPlateau();
						System.out.println(partie.getJoueurActif().getNomJoueur()+" entrez le nom du territoire de destination.");
						//String nomTerritoire = sc.nextLine();
						// Interface ---
						partie.waitSelecTerritoire();
						nomTerritoire = partie.getTerritoireSelectionee().getNom();
						// Interface ---
						//on vérifie si le territoire appartient bien au joueur
						for(int i=0; i < partie.getJoueurActif().getListeTerritoires().size(); i++) {
							if(partie.getJoueurActif().getListeTerritoires().get(i).getNom().compareTo(nomTerritoire)==0){
								Territoire territoire = partie.getJoueurActif().getListeTerritoires().get(i);
								territoirePossede = true ;
								//on place les pions
								listeTerritoire.add(territoire);
								System.out.println("pion placé");
								partie.getJoueurActif().renforts(listeTerritoire);
								territoire.update();     // [Interface]
								nbPionPlace = nbPionPlace +1;
							}	
						}
						if(territoirePossede==false) {
							System.out.println("Erreur :le territoire de destination n'appartient pas au joueur");
						}
					}
				}
			}
				
			partie.getJoueurActif().initialisationPions(); // tout les pions du joueur deviennent déplaçable
			

			
			if(partie.getJoueurActif().isIa()) {
				partie.etatPlateau();
				partie.getJoueurActif().attaqueIA();
				partie.etatPlateau();
				partie.getJoueurActif().deplacementIA();
				partie.etatPlateau();
				for(Continent c : partie.getListeContinents()) {
					for(Territoire t : c.getListeTerritoires()) {
						t.update();
					}
				}
			}
			
			else {
				partie.setActionJoueur("");
				while(partie.getActionJoueur().compareTo("fin du tour")!=0) { //tant que le jour n'indique pas la fin de son tour on reste dans la boucle
					partie.etatPlateau();
					System.out.println("Choisir une action");
//					String actionJoueur =  sc.nextLine();
//					partie.setActionJoueur(actionJoueur);
					// Interface ---
					partie.waitActionJoueur();
					// Interface
					
					//Attaque
					while(partie.getActionJoueur().compareTo("attaquer")==0) {
						//on verifie que le territoire attaquant appartient au joueur
						Territoire territoireAttaquant = new Territoire();
						boolean territoirePossede = false;
						String nomTerritoireAttaquant = "";
						while (territoirePossede==false) {
							System.out.println("Entrer le nom du territoire attaquant.");
//							String nomTerritoireAttaquant = sc.nextLine();
							// Interface ---
							partie.waitSelecTerritoire();
							nomTerritoireAttaquant = partie.getTerritoireSelectionee().getNom();
							// Interface ---
							for(int i=0; i < partie.getJoueurActif().getListeTerritoires().size(); i++) {
								if(partie.getJoueurActif().getListeTerritoires().get(i).getNom().compareTo(nomTerritoireAttaquant)==0){
									Territoire territoire = partie.getJoueurActif().getListeTerritoires().get(i);
									territoirePossede = true ;
									territoireAttaquant = territoire;
								}	
							}
							if(territoirePossede==false) {
								System.out.println("Erreur :le territoire attaquant n'appartient pas au joueur");
							}
						}
						
						
						//Nombre de pion attaquant
						System.out.println("Entre le nombre de pions attaquants.");
//						int nombrePion = sc.nextInt();
//						sc.nextLine();		
						int nombrePion = (int) nbTroupe.getSelectedItem();        // [Interface]
							
						//on verifie que le territoire defenseur n'appartient pas au joueur
						Territoire territoireDefenseur = new Territoire();
						String nomTerritoireDefenseur ="";
						while (territoirePossede==true) {
							territoirePossede = false;
							System.out.println("Entrer le nom du territoire defenseur.");
//							nomTerritoireDefenseur = sc.nextLine();
							// Interface ---
							partie.waitSelecTerritoire();
							nomTerritoireDefenseur = partie.getTerritoireSelectionee().getNom();
							// Interface ---
							for(int i=0; i < partie.getJoueurActif().getListeTerritoires().size(); i++) {
								if(partie.getJoueurActif().getListeTerritoires().get(i).getNom().compareTo(nomTerritoireDefenseur)==0){
									territoirePossede = true ;
								}	
							}
							if(territoirePossede==true) {
								System.out.println("Erreur :le territoire defenseur appartient au joueur");
							}
						}
						//on va chercher le territoire defenseur dans la liste de territoire des continents
						for (Continent continent : partie.getListeContinents()) {
							for (Territoire territoire : continent.getListeTerritoires()) {
								if (nomTerritoireDefenseur.compareTo(territoire.getNom())==0) {
									territoireDefenseur=territoire;
								}
							}
						}
						
						
						partie.getJoueurActif().attaquer(territoireAttaquant, nombrePion, territoireDefenseur);
						territoireAttaquant.update();
						territoireDefenseur.update();
						partie.setActionJoueur("");
					}//fin while attaquer
					
					
					//Deplacement
					while(partie.getActionJoueur().compareTo("deplacer")==0) {
						//territoire de depart
						String nomTerritoire = "";
						Territoire territoireDepart = new Territoire();
						boolean territoirePossede = false;
						while (territoirePossede==false) {
							System.out.println(partie.getJoueurActif().getNomJoueur()+" entre le nom du territoire de depart.");
							//String nomTerritoire = sc.nextLine();
							// Interface ---
							partie.waitSelecTerritoire();
							nomTerritoire = partie.getTerritoireSelectionee().getNom();
							// Interface ---
							for(int i=0; i < partie.getJoueurActif().getListeTerritoires().size(); i++) {
								if(partie.getJoueurActif().getListeTerritoires().get(i).getNom().compareTo(nomTerritoire)==0){
									Territoire territoire = partie.getJoueurActif().getListeTerritoires().get(i);
									territoirePossede = true ;
									territoireDepart=territoire;
								}	
							}
							if(territoirePossede==false) {
								System.out.println("Erreur :le territoire de depart n'appartient pas au joueur");
							}
						}
						//nombre de pions à deplacer
						System.out.println("Nombre de pions à déplacer");
//						int nombrePion = sc.nextInt();
//						sc.nextLine();
						int nombrePion = (int) nbTroupe.getSelectedItem();        // [Interface]
						
						//territoire d'arrivée
						nomTerritoire = "";
						Territoire territoireArrivee = new Territoire();
						territoirePossede = false;
						while (territoirePossede==false) {
							System.out.println(partie.getJoueurActif().getNomJoueur()+" entre le nom du territoire d'arrivée.");
//							String nomTerritoire = sc.nextLine();
							// Interface ---
							partie.waitSelecTerritoire();
							nomTerritoire = partie.getTerritoireSelectionee().getNom();
							// Interface ---
							for(int i=0; i < partie.getJoueurActif().getListeTerritoires().size(); i++) {
								if(partie.getJoueurActif().getListeTerritoires().get(i).getNom().compareTo(nomTerritoire)==0){
									Territoire territoire = partie.getJoueurActif().getListeTerritoires().get(i);
									territoirePossede = true ;
									territoireArrivee=territoire;
								}	
							}
							if(territoirePossede==false) {
								System.out.println("Erreur :le territoire d'arrivée n'appartient pas au joueur");
							}
						}
						
						partie.getJoueurActif().deplacer(territoireDepart, nombrePion, territoireArrivee);
						territoireDepart.update();
						territoireArrivee.update();
						
						partie.setActionJoueur("");
					}//fin while deplacer
				
					
				}// fin while action du joueur
			}
			System.out.println("fini");
			partie.getJoueurActif().finTourJoueur();
		
		
		}//fin while partie isEnCours
		System.out.println("Partie finie");
		
		
	sc.close();
	}
}
