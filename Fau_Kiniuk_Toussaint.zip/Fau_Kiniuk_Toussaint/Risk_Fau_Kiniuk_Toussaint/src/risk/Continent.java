package risk;

import java.util.ArrayList;
import java.util.List;

/**
 * classe Continent qui va repr�senter un continent : agr�gat de territoires
 * @author fau_kinuk_toussaint
 *
 */
public class Continent {
	
	//d�claration des attributs
	/**
	 * attribut String nom : nom du continent
	 */
	private String nom;
	
	/**
	 * attribut List<Territoire> listeTerritoires : liste des territoires composants le continent
	 */
	private List<Territoire> listeTerritoires;
	
	/**
	 * attribut int nbRenfort : nombre de renforts suppl�mentaires si le joueur poss�de tous les territoires d'un continent 
	 */
	private int nbRenfort;
	
	//m�thode
	/**
	 * m�thode verifPossession : permet de v�rifier si tous les territoires du continent appartiennent � un m�me joueur donn�
	 * @param joueur : joueur potentiel possesseur du continent
	 * @return : si le joueur poss�de tous les territoires du contient, la m�thode renvoie true, sinon false
	 */
	public boolean verifPossession(Joueur joueur) {
		//on parcourt tous les territoires de la liste de territoires 
		for(Territoire territoire:this.listeTerritoires){
			if (territoire.getPossesseur() != joueur) {
				return false;
			}
		}
		return true ;
	}
	
	/**
	 * m�thode addTerritoire : permet d'ajouter un territoire � la liste de territoires composant le continent
	 * @param territoire : ledit territoire
	 */
	public void addTerritoire(Territoire territoire) {
		this.listeTerritoires.add(territoire);
	}
	
	/**
	 * constructeur
	 * m�thode Continent qui permet de cr�er un continent
	 * @param nom : le nom du contient
	 * @param nbRenfort : le nombre de renforts attribu�s � un joueur qui poss�de tous les territoires du continent
	 */
	public Continent(String nom, int nbRenfort) {
		this.nom = nom;
		this.listeTerritoires = new ArrayList<Territoire>();
		this.nbRenfort = nbRenfort;
	}
	
	//getter et setter

	/**
	 * getter
	 * m�thode getNbRenfort qui permet d'acc�der au nombre de renforts suppl�mentaires si tout le continent est poss�d� par le m�me joueur
	 * @return int nbRenfort : ledit nombre de renforts
	 */
	public int getNbRenfort() {
		return nbRenfort;
	}


	/**
	 * getter
	 * m�thode getListeTerritoires qui permet d'acc�der � la liste de territoires d'un continent
	 * @return  listeTerritoires : la liste en question
	 */
	public List<Territoire> getListeTerritoires() {
		return listeTerritoires;
	}
	
}
