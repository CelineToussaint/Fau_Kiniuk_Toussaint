package risk;

import java.awt.Image;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;

import io.BoutonTerritoire;
import io.FondDeCarte;
import io.NbTroupeTerritoire;

/**
 * 
 * @author fau_kinuk_toussaint
 * classe ImportCarte : classe qui va interagir avec la base de donn�es sous fichier texte pour importer les cartes.
 *
 */

public class ImportCarte {
	
	
	/**
	 * constructeur de la classe ImportCarte
	 * m�thode ImportCarte : permet de cr�er un importeur de carte.
	 */
	public ImportCarte () {} 
	
	/** 
	 * m�thode importerCarte : permet d'importer 4 listes de donn�es � partir d'un fichier contenant 4 documents textes .
	 * @param filePath : chemin d'acc�s du dossier.
	 * @return importations : les importations effectu�es
	 */
	public List<List<String>> importerCarte(String filePath) {
		
		List<List<String>> importations = new ArrayList();
		List<String> impCont = new ArrayList() ;
		List<String> impTerr = new ArrayList() ;
		List<String> impFron = new ArrayList() ;
		List<String> impPosi = new ArrayList() ;
		
		Path p1 = Paths.get(filePath+"/continent.txt"); // creation de l'objet Path
		try (BufferedReader reader = Files.newBufferedReader(p1)) { // ouverture d'un buffer en lecture
			String line;
			while ((line = reader.readLine()) != null) {
				impCont.add(line);
			}
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
		importations.add(impCont);
		
		Path p2 = Paths.get(filePath+"/territoire.txt"); // creation de l'objet Path
		try (BufferedReader reader = Files.newBufferedReader(p2)) { // ouverture d'un buffer en lecture
			String line;
			while ((line = reader.readLine()) != null) {
				impTerr.add(line);
			}
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
		importations.add(impTerr);
		
		Path p3 = Paths.get(filePath+"/frontiere.txt"); // creation de l'objet Path
		try (BufferedReader reader = Files.newBufferedReader(p3)) { // ouverture d'un buffer en lecture
			String line;
			while ((line = reader.readLine()) != null) {
				impFron.add(line);
			}
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
		importations.add(impFron);
		
		Path p4 = Paths.get(filePath+"/btnTerr.txt"); // creation de l'objet Path
		try (BufferedReader reader = Files.newBufferedReader(p4)) { // ouverture d'un buffer en lecture
			String line;
			while ((line = reader.readLine()) != null) {
				impPosi.add(line);
			}
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
		importations.add(impPosi);
		
		return importations;
	}
	
	/** 
	 * m�thode creationContinent : permet de cr�er les continents � partir des donn�es .
	 * @param impCont : liste de donn�es concernant les continents .
	 * @param partie : partie dans laquelle on cr�e les continents .
	 */
	public void creationContinents(List<String> impCont,Partie partie) {
		
		int sep1 = 0;
		int sep2 = 0;
		
		for (String line : impCont) {
			sep1 = 0;
			sep2 = 0;
			for (int i=0;i<line.length();i++) {
				if (line.substring(i,i+1).compareTo(";")==0) {					
					if (sep1 == 0) {
						sep1 = i;
					}
					else {
						sep2 = i;
					}
				}
			}
			int val_renfort = Integer.valueOf(line.substring(sep2+1)).intValue();
			Continent c = new Continent(line.substring(sep1+1,sep2),val_renfort);
			partie.addContinent(c);
		}
	}
	
	/** 
	 * m�thode creationContinent : permet de cr�er les territoires � partir des donn�es .
	 * @param impTerr : liste de donn�es concernant les territoires .
	 * @param partie : partie dans laquelle on cr�e les territoires .
	 */
	public void creationTerritoires(List<String> impTerr,Partie partie) {

		int sep1 = 0;
		int sep2 = 0;
		
		for (String line : impTerr) {
			sep1 = 0;
			sep2 = 0;
			for (int i=0;i<line.length();i++) {
				if (line.substring(i,i+1).compareTo(";")==0) {
					if (sep1 == 0) {
						sep1 = i;
					}
					else {
						sep2 = i;
					}
				}
			}
			int continent = Integer.valueOf(line.substring(sep2+1)).intValue();
			Territoire t = new Territoire(line.substring(sep1+1,sep2));
			partie.getListeContinents().get(continent-1).addTerritoire(t);
		}
	}

	/** 
	 * m�thode creationFrontiere : permet de cr�er les fronti�res entre les territoires �partir des donn�es .
	 * @param impTerr : liste de donn�es concernant les territoires .
	 * @param impFron : liste de donn�es concernant les fronti�res .
	 * @param partie : partie dans laquelle on cr�e les fronti�res .
	 */
	public void creationFrontiere(List<String> impTerr,List<String> impFron,Partie partie) {
		
		int sep1 = 0;
		int sep2 = 0;
		String nomTerr1 = "";
		String nomTerr2 = "";
		Territoire territoire1 = null;
		Territoire territoire2 = null;
		
		List<String> listTerr = new ArrayList<>();
		
		for (String line : impTerr) {
			sep1 = 0;
			sep2 = 0;
			for (int i=0;i<line.length();i++) {
				if (line.substring(i,i+1).compareTo(";")==0) {
					if (sep1 == 0) {
						sep1 = i;
					}
					else {
						sep2 = i;
					}
				}
			}
			listTerr.add(line.substring(sep1+1,sep2));
		}
		
		for (String line : impFron) {
			sep1 = 0;
			sep2 = 0;
			
			for (int i=0;i<line.length();i++) {
				if (line.substring(i,i+1).compareTo(";")==0) {
					if (sep1 == 0) {
						sep1 = i;
					}
					else {
						sep2 = i;
					}
				}
			}
			nomTerr1 = listTerr.get(Integer.valueOf(line.substring(sep1+1,sep2)).intValue()-1);
			for(Continent c : partie.getListeContinents()) {
				for(Territoire t : c.getListeTerritoires()) {
					if (t.getNom().compareTo(nomTerr1)==0) {
						territoire1 = t;
					}
				}
			}
			nomTerr2 = listTerr.get(Integer.valueOf(line.substring(sep2+1,line.length())).intValue()-1);
			for(Continent c : partie.getListeContinents()) {
				for(Territoire t : c.getListeTerritoires()) {
					if (t.getNom().compareTo(nomTerr2)==0) {
						territoire2 = t;
					}
				}
			}
			
			territoire1.addTerritoireAdjacent(territoire2);
			
		}
	}
	
	public Image importerFondDeCarte(String filePath) {
		ImageIcon ii = new ImageIcon(filePath+"/Fond.png");
		return ii.getImage();
	}
	
	public void creationBouton(List<String> impPosi,FondDeCarte fondDeCarte,Partie partie) {
		int sep1 = 0;
		int sep2 = 0;
		String nomTerr = "";
		Territoire territoire = null;
			
		for (String line : impPosi) {
	
			sep1 = 0;
			sep2 = 0;
			for (int i=0;i<line.length();i++) {
				if (line.substring(i,i+1).compareTo(";")==0) {
					if (sep1 == 0) {
						sep1 = i;
					}
					else {
						sep2 = i;
					}
				}
			}
			
			nomTerr = line.substring(0,sep1);
			for(Continent c : partie.getListeContinents()) {
				for(Territoire t : c.getListeTerritoires()) {
					if (t.getNom().compareTo(nomTerr)==0) {
						territoire = t;
					}
				}
			}
			if (territoire != null) {
				int x = Integer.valueOf(line.substring(sep1+1,sep2)).intValue();
				int y = Integer.valueOf(line.substring(sep2+1,line.length())).intValue();
				
				BoutonTerritoire bouton = new BoutonTerritoire(partie,territoire,x,y) ;
				fondDeCarte.add(bouton);
				territoire.setBoutonAssocie(bouton);
				NbTroupeTerritoire label = new NbTroupeTerritoire(partie,territoire,x+50,y-20) ;
				fondDeCarte.add(label);
				territoire.setLabelAssocie(label);
			}
			
		}
	}
	
}
